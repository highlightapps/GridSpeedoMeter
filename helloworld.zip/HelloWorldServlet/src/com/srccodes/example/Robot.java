package com.srccodes.example;

public class Robot {

	private int currentX = 0, currentY = 5, previousX, previousY;
	private boolean lastMoveIsX = true;

	public Robot() {

	}

	public Robot(int x, int y) {
		previousX = currentX;
		previousY = currentY;
		currentX = x;
		currentY = y;
	}

	public void moveX(int dx) {
		lastMoveIsX = true;
		previousX = currentX;
		previousY = currentY;
		currentX = currentX + dx;
	}

	public void moveY(int dy) {
		lastMoveIsX = false;
		previousX = currentX;
		previousY = currentY;
		currentY = currentY + dy;
	}

	public void printCurrentCoordinates() {
		System.out.println(currentX + " " + currentY);
	}

	public void printLastCoordinates() {
		System.out.println(previousX + " " + previousY);
	}

	public void printLastMove() {
		if (lastMoveIsX)
			System.out.println("x " + (currentX - previousX));
		else
			System.out.println("y " + (currentY - previousY));
	}

}
